-- 錯題本 D1 資料表

CREATE TABLE IF NOT EXISTS students (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS entries (
  id            TEXT PRIMARY KEY,
  student_id    TEXT NOT NULL,
  unit          TEXT NOT NULL,
  subtopic      TEXT,
  error_type    TEXT,
  difficulty    TEXT,
  transcription TEXT,
  key_point     TEXT,
  hint          TEXT,
  image_key     TEXT,
  created_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_entries_student ON entries(student_id);
CREATE INDEX IF NOT EXISTS idx_entries_unit    ON entries(unit);
