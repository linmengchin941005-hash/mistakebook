// 共用工具（檔名以 _ 開頭，不會被當成路由）

export const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...headers },
  });

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

// 是否帶了正確的老師密碼
export const teacherOk = (request, env) =>
  !!env.TEACHER_PASSWORD &&
  request.headers.get("x-teacher-key") === env.TEACHER_PASSWORD;

// 108 課綱 第三冊 數A：三角 / 指對數函數 / 平面向量
export const UNITS = [
  "三角函數的圖形（弧度量）",
  "和差角公式",
  "二倍角與半角公式",
  "正餘弦函數的疊合",
  "指數函數",
  "對數與對數律",
  "對數函數",
  "平面向量的運算",
  "平面向量的內積",
  "平面向量的應用（面積、二階行列式）",
];
