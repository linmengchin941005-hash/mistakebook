import { json, teacherOk } from "./_utils.js";

// GET /api/stats  -> 老師總覽（每個學生的題數＋全班單元分佈），限老師
export async function onRequestGet({ request, env }) {
  if (!teacherOk(request, env)) return json({ error: "需要老師密碼" }, 403);

  const perStudent = await env.DB.prepare(
    `SELECT s.id, s.name, COUNT(e.id) AS total, COUNT(DISTINCT e.unit) AS units
     FROM students s LEFT JOIN entries e ON e.student_id = s.id
     GROUP BY s.id, s.name, s.created_at
     ORDER BY s.created_at ASC`
  ).all();

  const byUnit = await env.DB.prepare(
    `SELECT unit, COUNT(*) AS n FROM entries GROUP BY unit ORDER BY n DESC`
  ).all();

  return json({
    perStudent: perStudent.results || [],
    byUnit: byUnit.results || [],
  });
}
