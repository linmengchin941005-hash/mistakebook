import { json, uid } from "./_utils.js";

// GET /api/entries?student_id=xxx  -> 該學生的錯題（不帶 student_id 則回全部）
export async function onRequestGet({ request, env }) {
  const sid = new URL(request.url).searchParams.get("student_id");
  const stmt = sid
    ? env.DB.prepare(
        "SELECT * FROM entries WHERE student_id = ? ORDER BY created_at DESC"
      ).bind(sid)
    : env.DB.prepare("SELECT * FROM entries ORDER BY created_at DESC");
  const { results } = await stmt.all();
  return json({ entries: results || [] });
}

// POST /api/entries  { student_id, image(base64), unit, subtopic, error_type, difficulty, transcription, key_point, hint }
export async function onRequestPost({ request, env }) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "格式錯誤" }, 400);
  }
  const { student_id, image } = body;
  if (!student_id) return json({ error: "缺少 student_id" }, 400);

  const id = uid();

  // 圖片存 R2，物件 key = 記錄 id（單一片段，方便當作 /api/image/:key）
  let image_key = null;
  if (image) {
    try {
      const bytes = Uint8Array.from(atob(image), (c) => c.charCodeAt(0));
      image_key = id;
      await env.BUCKET.put(image_key, bytes, {
        httpMetadata: { contentType: "image/jpeg" },
      });
    } catch {
      return json({ error: "圖片儲存失敗" }, 500);
    }
  }

  const now = Date.now();
  await env.DB.prepare(
    `INSERT INTO entries
     (id, student_id, unit, subtopic, error_type, difficulty, transcription, key_point, hint, image_key, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      id,
      student_id,
      body.unit || "未分類",
      body.subtopic || "",
      body.error_type || "",
      body.difficulty || "",
      body.transcription || "",
      body.key_point || "",
      body.hint || "",
      image_key,
      now
    )
    .run();

  return json({ id, image_key, created_at: now });
}
