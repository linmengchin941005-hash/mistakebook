import { json, teacherOk } from "./_utils.js";

// 對所有 /api/* 生效。若有設定 ACCESS_CODE，就要求前端帶 x-access-code。
// 圖片路由 (/api/image/*) 不擋，因為 <img> 無法帶自訂標頭；圖片 key 是隨機值，猜不到。
export async function onRequest(context) {
  const { request, env, next } = context;
  const url = new URL(request.url);

  if (request.method === "OPTIONS") return new Response(null, { status: 204 });

  const isImage = url.pathname.startsWith("/api/image/");
  if (env.ACCESS_CODE && !isImage) {
    const ok =
      request.headers.get("x-access-code") === env.ACCESS_CODE ||
      teacherOk(request, env);
    if (!ok) return json({ error: "存取碼錯誤或未提供" }, 401);
  }
  return next();
}
