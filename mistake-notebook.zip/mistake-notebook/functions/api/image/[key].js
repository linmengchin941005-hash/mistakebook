import { json } from "../_utils.js";

// GET /api/image/:key  -> 從 R2 讀圖回傳
export async function onRequestGet({ params, env }) {
  const obj = await env.BUCKET.get(params.key);
  if (!obj) return json({ error: "找不到圖片" }, 404);

  const headers = new Headers();
  headers.set("content-type", obj.httpMetadata?.contentType || "image/jpeg");
  headers.set("cache-control", "private, max-age=3600");
  return new Response(obj.body, { headers });
}
