import { json, UNITS } from "./_utils.js";

// POST /api/classify  { image: <base64 jpeg, 不含 data: 前綴> }
// 回傳辨識結果 JSON（此時還沒存檔，讓學生先確認單元）
export async function onRequestPost({ request, env }) {
  if (!env.ANTHROPIC_API_KEY)
    return json({ error: "伺服器沒設定 ANTHROPIC_API_KEY" }, 500);

  let image;
  try {
    ({ image } = await request.json());
  } catch {
    return json({ error: "請求格式錯誤" }, 400);
  }
  if (!image) return json({ error: "缺少影像資料" }, 400);

  const prompt =
`你是高中數學家教的助教。學生是「高二上學期（數學A）」，這是一張他做錯的數學題目照片。
單元請「優先」從下面清單挑一個最貼切的：
${UNITS.join("、")}
真的都不屬於，才自己填一個簡短單元名。

只回傳一個 JSON 物件（不要任何說明、不要 markdown、不要 code fence）：
{
 "transcription":"把題目打成文字，數學式用 LaTeX（行內用 $...$）",
 "unit":"所屬單元（優先用上面清單的字）",
 "subtopic":"更細的主題，一句話內",
 "errorType":"學生最可能錯的原因，例如：計算錯誤、觀念不清、公式記錯、審題不清",
 "difficulty":"易 或 中 或 難，擇一",
 "keyPoint":"這題核心觀念，一句話",
 "hint":"給學生的提示，引導思考但不要直接給答案"
}
若照片看不清楚或不是數學題，unit 填「無法辨識」。只回傳 JSON。`;

  let resp;
  try {
    resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: env.CLAUDE_MODEL || "claude-sonnet-5",
        max_tokens: 1024,
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } },
              { type: "text", text: prompt },
            ],
          },
        ],
      }),
    });
  } catch {
    return json({ error: "無法連線辨識服務" }, 502);
  }

  if (!resp.ok) {
    const detail = await resp.text().catch(() => "");
    return json({ error: "辨識服務回應錯誤 (" + resp.status + ")", detail }, 502);
  }

  const data = await resp.json();
  let text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .join("")
    .trim();
  const a = text.indexOf("{"), b = text.lastIndexOf("}");
  if (a >= 0 && b > a) text = text.slice(a, b + 1);

  try {
    return json(JSON.parse(text));
  } catch {
    return json({ error: "辨識結果解析失敗", raw: text }, 502);
  }
}
