import { json, uid, teacherOk } from "./_utils.js";

// GET /api/students  -> 名單（學生端也會用來選人）
export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT id, name, created_at FROM students ORDER BY created_at ASC"
  ).all();
  return json({ students: results || [] });
}

// POST /api/students  { name }  -> 新增學生（限老師）
export async function onRequestPost({ request, env }) {
  if (!teacherOk(request, env)) return json({ error: "需要老師密碼" }, 403);

  let name;
  try {
    ({ name } = await request.json());
  } catch {
    return json({ error: "格式錯誤" }, 400);
  }
  name = (name || "").trim();
  if (!name) return json({ error: "名字不能空白" }, 400);

  const id = uid();
  await env.DB.prepare(
    "INSERT INTO students (id, name, created_at) VALUES (?, ?, ?)"
  )
    .bind(id, name, Date.now())
    .run();
  return json({ id, name });
}

// DELETE /api/students?id=xxx  -> 刪學生＋他的所有錯題與圖片（限老師）
export async function onRequestDelete({ request, env }) {
  if (!teacherOk(request, env)) return json({ error: "需要老師密碼" }, 403);

  const id = new URL(request.url).searchParams.get("id");
  if (!id) return json({ error: "缺少 id" }, 400);

  const { results } = await env.DB.prepare(
    "SELECT image_key FROM entries WHERE student_id = ?"
  )
    .bind(id)
    .all();
  for (const r of results || []) {
    if (r.image_key) await env.BUCKET.delete(r.image_key).catch(() => {});
  }
  await env.DB.prepare("DELETE FROM entries WHERE student_id = ?").bind(id).run();
  await env.DB.prepare("DELETE FROM students WHERE id = ?").bind(id).run();
  return json({ ok: true });
}
