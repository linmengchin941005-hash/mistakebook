import { json } from "../_utils.js";

// DELETE /api/entries/:id  -> 刪一筆錯題＋它的圖片
export async function onRequestDelete({ params, env }) {
  const id = params.id;
  const row = await env.DB.prepare(
    "SELECT image_key FROM entries WHERE id = ?"
  )
    .bind(id)
    .first();
  if (!row) return json({ error: "找不到這一筆" }, 404);

  if (row.image_key) await env.BUCKET.delete(row.image_key).catch(() => {});
  await env.DB.prepare("DELETE FROM entries WHERE id = ?").bind(id).run();
  return json({ ok: true });
}
