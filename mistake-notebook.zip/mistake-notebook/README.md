# 錯題本（高二上 · 數A）

學生拍照上傳錯題 → 自動讀題、分類單元、給重點提示 → 依單元整理成錯題本。
老師端可看每個學生、全班最常錯的單元。

跑在 Cloudflare 上：**Pages（前端）+ Pages Functions（API）+ D1（資料庫）+ R2（存圖片）+ Anthropic API（辨識）**。

---

## 你需要先準備

1. 一個 Cloudflare 帳號
2. 一把 Anthropic API key（platform.claude.com → API Keys）
3. 電腦裝好 Node.js（用 wrangler 指令部署最省事）

---

## 檔案結構

```
mistake-notebook/
├─ public/
│  └─ index.html            前端整包（拍照、錯題本、老師端）
├─ functions/api/           後端 API（Cloudflare Functions）
│  ├─ _utils.js             共用工具＋單元清單
│  ├─ _middleware.js        存取碼驗證
│  ├─ classify.js           呼叫 Anthropic 辨識題目
│  ├─ students.js           名單：列出／新增／刪除
│  ├─ entries.js            錯題：列出／新增（存圖到 R2）
│  ├─ entries/[id].js       刪單筆錯題
│  ├─ image/[key].js        從 R2 讀圖
│  └─ stats.js              老師總覽統計
├─ schema.sql               資料表
├─ wrangler.toml            Cloudflare 設定
└─ README.md
```

---

## 部署（推薦：用 wrangler 指令）

在專案資料夾底下開終端機，依序執行。

**1. 登入**
```bash
npx wrangler login
```

**2. 建 D1 資料庫**
```bash
npx wrangler d1 create mistake-notebook
```
它會印出一段 `database_id`，把它貼進 `wrangler.toml` 裡 `database_id` 那行。

**3. 建資料表**
```bash
npx wrangler d1 execute mistake-notebook --file=./schema.sql --remote
```

**4. 建 R2 儲存桶**
```bash
npx wrangler r2 bucket create mistake-notebook-images
```

**5. 部署網站**
```bash
npx wrangler pages deploy public
```
第一次會問你 Pages 專案名稱，取一個（例如 `mistake-notebook`）。完成後會給你一個網址。

**6. 設定機密與變數**（在 Pages 專案建立後）
```bash
npx wrangler pages secret put ANTHROPIC_API_KEY
npx wrangler pages secret put TEACHER_PASSWORD
npx wrangler pages secret put ACCESS_CODE      # 選用，不想要就跳過
```
每個指令會叫你貼上值。`CLAUDE_MODEL` 如需更改可到 dashboard 的環境變數設定。

> 綁定（D1 的 `DB`、R2 的 `BUCKET`）已寫在 `wrangler.toml`，用 wrangler 部署會自動套用。設完 secret 後再 `npx wrangler pages deploy public` 重新部署一次讓設定生效。

---

## 部署（全部用 Cloudflare 網頁後台，不碰指令）

1. **D1**：Workers & Pages → D1 → 建立 `mistake-notebook` → 進去用 Console 貼上 `schema.sql` 內容執行。
2. **R2**：R2 → 建立儲存桶 `mistake-notebook-images`。
3. **Pages**：Workers & Pages → Create → Pages → 用 Git 連你的 repo，或選 Direct Upload 上傳 `public/` 內容（`functions/` 要一起帶上）。
4. **綁定**：進 Pages 專案 → Settings → Functions → Bindings：
   - D1 database：變數名 `DB` → 選 `mistake-notebook`
   - R2 bucket：變數名 `BUCKET` → 選 `mistake-notebook-images`
5. **環境變數**：Settings → Environment variables，新增：
   - `ANTHROPIC_API_KEY`（設為 Secret）
   - `TEACHER_PASSWORD`（設為 Secret）
   - `ACCESS_CODE`（選用）
   - `CLAUDE_MODEL`（選用，預設 `claude-sonnet-5`）
6. 存檔後重新部署一次。

---

## 環境變數說明

| 變數 | 必填 | 說明 |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ | 你的 Anthropic API key，用來辨識題目 |
| `TEACHER_PASSWORD` | ✅ | 老師模式密碼（新增／刪除學生、看統計） |
| `ACCESS_CODE` | 選用 | 設了的話，學生要先輸入這組碼才能用；留空＝任何人有網址就能用 |
| `CLAUDE_MODEL` | 選用 | 預設 `claude-sonnet-5`。想更省可用 `claude-haiku-4-5-20251001`；想更準可用 `claude-opus-5` |

---

## 開始使用

1. 打開網址，切到「老師」，輸入 `TEACHER_PASSWORD`，用「＋ 新增學生」把學生名單建好。
2. 學生打開同一個網址（若有設 `ACCESS_CODE`，先輸入一次），選自己的名字 → 拍照上傳。
3. 上傳後會自動分類，學生確認單元就存進錯題本；老師端隨時看得到。

---

## 費用與注意

- **Cloudflare**：Pages／D1／R2 都有免費額度，這種小班用量通常在免費範圍內。
- **Anthropic API**：每上傳一張圖算一次辨識，依你選的模型計費（sonnet 便宜、opus 較貴、haiku 最省）。到 platform.claude.com 可看用量。
- **安全性**：這是給小班家教用的輕量驗證（存取碼＋老師密碼），不是企業級帳號系統。照片存在你自己的 R2、資料在你自己的 D1，不會外流第三方，但請不要把網址公開貼在公開場合。
- 建議在 Anthropic 後台設每月用量上限，避免意外爆量。

---

## 想改的地方

- **換單元範圍**：改 `functions/api/_utils.js` 的 `UNITS` 陣列，同時把 `public/index.html` 裡的 `UNITS` 改成一樣，`classify.js` 的提示詞也會自動吃到新清單。
- **改辨識邏輯／欄位**：改 `classify.js` 的提示詞。
